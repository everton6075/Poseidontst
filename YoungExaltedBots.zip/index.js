const express = require('express');
const session = require('express-session');
const passport = require('passport');
const DiscordStrategy = require('passport-discord').Strategy;
const mongoose = require('mongoose');
const expressLayouts = require('express-ejs-layouts');

const app = express();

// Conexão ao MongoDB
mongoose.connect('mongodb+srv://poseidonn:poseidonnbot@poseidonn.yessm3i.mongodb.net/poseidon?retryWrites=true&w=majority', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

// Modelo do usuário
const User = mongoose.model('User', new mongoose.Schema({
    discordId: String,
    username: String,
    avatar: String,
    money: { type: Number, default: 0 },
    lastDaily: Date,
    lastDailyIP: String,
}));

// Configuração do Passport.js
passport.use(new DiscordStrategy({
    clientID: '1233802594841919639',
    clientSecret: 'OBF5-EkvMrQMcI7l7GTOGmfXzGRWWz0b',
    callbackURL: 'https://everton60755.YoungExaltedBots.repl.co/auth/discord/callback',
    scope: ['identify'],
}, async (accessToken, refreshToken, profile, done) => {
    try {
        let user = await User.findOne({ discordId: profile.id });
        if (!user) {
            user = new User({
                discordId: profile.id,
                username: profile.username,
                avatar: profile.avatar,
            });
            await user.save();
        }
        return done(null, user);
    } catch (err) {
        console.error('Error during Discord strategy:', err);
        return done(err, null);
    }
}));

passport.serializeUser((user, done) => done(null, user.id));
passport.deserializeUser((id, done) => User.findById(id, (err, user) => done(err, user)));

// Configurações de Sessão
app.use(session({
    secret: 'supersecret',
    resave: false,
    saveUninitialized: false,
}));

app.use(passport.initialize());
app.use(passport.session());

// Configuração do EJS e dos arquivos estáticos
app.set('view engine', 'ejs');
app.use(expressLayouts);
app.use(express.static('public'));

// Middleware para verificar se o usuário está autenticado
function isAuthenticated(req, res, next) {
    if (req.isAuthenticated()) {
        return next();
    }
    res.redirect('/auth/discord');
}

// Rotas
app.get('/', isAuthenticated, (req, res) => {
    res.render('index', { user: req.user });
});

app.get('/ranking', isAuthenticated, async (req, res) => {
    const users = await User.find().sort({ money: -1 }).limit(10);
    res.render('ranking', { users, user: req.user });
});

app.post('/daily', isAuthenticated, async (req, res) => {
    const user = await User.findById(req.user.id);
    const now = new Date();

    if (user.lastDaily && now - user.lastDaily < 24 * 60 * 60 * 1000) {
        return res.status(429).send('Você já resgatou seu daily hoje.');
    }

    user.lastDaily = now;
    user.money += 50;
    await user.save();

    res.redirect('/');
});

app.get('/auth/discord', passport.authenticate('discord'));
app.get('/auth/discord/callback',
    passport.authenticate('discord', { failureRedirect: '/' }),
    (req, res) => res.redirect('/')
);

// Inicie o servidor
app.listen(3000, () => console.log('Servidor rodando na porta 3000'));
